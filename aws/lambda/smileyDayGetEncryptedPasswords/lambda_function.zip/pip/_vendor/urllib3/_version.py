# This file is protected via CODEOWNERS
__version__ = "1.26.9"
